import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class QuizzAutomation {

    static WebDriver driver;
    static FileWriter logWriter;

    public static void main(String[] args) throws Exception {

        // -------------------------
        // SETUP
        // -------------------------
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        // Log file
        logWriter = new FileWriter("selenium-log.txt", false);

        log("===== QUIZ AUTOMATION STARTED =====");

        // -------------------------
        // 1. LOAD QUIZ PAGE
        // -------------------------
        String path = "file:///C:/Users/SAIKIRAN/Downloads/Frugal_Testing_QuizApp-main/Frugal_Testing_QuizApp-main/quiz.html";
        driver.get(path);
        Thread.sleep(1000);

        takeScreenshot("01_Landing_Page.png");
        log("Loaded Quiz Page");
        log("Page Title: " + driver.getTitle());
        log("Page URL: " + driver.getCurrentUrl());

        // -------------------------
        // 2. CLICK START QUIZ
        // -------------------------
        WebElement startBtn = driver.findElement(By.id("startBtn"));
        startBtn.click();
        Thread.sleep(1500);

        takeScreenshot("02_Quiz_Started.png");
        log("Quiz Started — Question 1 displayed");

        // -------------------------
        // 3. ANSWER ALL QUESTIONS
        // -------------------------
        for (int i = 1; i <= 10; i++) {

            log("Answering Question " + i);
            takeScreenshot("Question_" + i + ".png");

            // Select the THIRD OPTION every time (example requirement)
            WebElement choice = driver.findElement(By.xpath("//div[@class='choice'][3]"));
            choice.click();
            Thread.sleep(800);

            // Click NEXT except after last question
            if (i < 10) {
                driver.findElement(By.id("nextBtn")).click();
                Thread.sleep(1200);
            }
        }

        // -------------------------
        // 4. SUBMIT QUIZ
        // -------------------------
        driver.findElement(By.id("submitBtn")).click();
        Thread.sleep(1500);

        takeScreenshot("06_Result_Page.png");
        log("Quiz Submitted. Results displayed.");

        // -------------------------
        // 5. VERIFY SCORE PAGE
        // -------------------------
        String score = driver.findElement(By.id("scoreText")).getText();
        String correct = driver.findElement(By.id("correctCount")).getText();
        String wrong = driver.findElement(By.id("wrongCount")).getText();

        log("Score shown: " + score);
        log("Correct answers: " + correct);
        log("Wrong answers: " + wrong);

        log("===== QUIZ AUTOMATION COMPLETED SUCCESSFULLY =====");

        // cleanup
        logWriter.close();
        driver.quit();
    }

    // -------------------------
    // Take Screenshot
    // -------------------------
    public static void takeScreenshot(String filename) {
        try {
            File scr = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            File destDir = new File("screenshots");
            if (!destDir.exists()) destDir.mkdir();

            File destFile = new File(destDir, filename);
            FileUtils.copyFile(scr, destFile);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // -------------------------
    // Logging Helper
    // -------------------------
    public static void log(String message) throws IOException {
        logWriter.write(message + "\n");
        System.out.println(message);
    }
}
